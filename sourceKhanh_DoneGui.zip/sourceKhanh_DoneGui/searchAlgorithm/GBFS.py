def GBFS_solve():
	print("Something")