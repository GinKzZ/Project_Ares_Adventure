import os
import sys
import pygame
from . import gui_Attribute
sys.path.append(os.path.abspath(".."))
import Function

exit_game = False
pygame.font.init()
curPath = os.getcwd()
image1 = pygame.image.load(curPath + "/guiSource/wallpaper/wpp1.png")
image2 = pygame.image.load(curPath + "/guiSource/wallpaper/wpp2.webp")
image1 = pygame.transform.scale(image1, (gui_Attribute.WIDTH1_SCREEN, gui_Attribute.HEIGHT1_SCREEN))
image2 = pygame.transform.scale(image2, (gui_Attribute.WIDTH2_SCREEN, gui_Attribute.HEIGHT2_SCREEN))
imagerect1 = image1.get_rect()
imagerect2 = image2.get_rect()
imagerect1.center = ((gui_Attribute.WIDTH1_SCREEN/2, gui_Attribute.HEIGHT1_SCREEN/2))
imagerect2.center = ((gui_Attribute.WIDTH2_SCREEN/2, gui_Attribute.HEIGHT2_SCREEN/2))

font1 = pygame.font.Font(None, gui_Attribute.TEXT_FONT1)
font2 = pygame.font.Font(None, gui_Attribute.TEXT_FONT2)
font3 = pygame.font.Font(None, gui_Attribute.TEXT_FONT3)

button_start_surface = pygame.Surface(gui_Attribute.BUTTON_START_SIZE, pygame.SRCALPHA)
button_start_surface.fill(gui_Attribute.GRAY_BUTTON) 
text_button_start = font1.render("START", True, gui_Attribute.BLACK)

button_exit_surface = pygame.Surface(gui_Attribute.BUTTON_EXIT_SIZE, pygame.SRCALPHA)
button_exit_surface.fill(gui_Attribute.GRAY_BUTTON) 
text_button_exit = font1.render("EXIT", True, gui_Attribute.BLACK)

box_input_surface = pygame.Surface(gui_Attribute.BOX_INPUT_SIZE, pygame.SRCALPHA)
box_input_surface.fill(gui_Attribute.GRAY_BUTTON) 
text_box_input = font2.render("CHOOSE YOUR INPUT", True, gui_Attribute.RED)

box_controller = pygame.Surface(gui_Attribute.BOX_CONTROLLER_SIZE, pygame.SRCALPHA)
box_controller.fill(gui_Attribute.GRAY_BUTTON) 

back_button = pygame.image.load(curPath + "/guiSource/icon/back.png")
back_button = pygame.transform.scale(back_button, gui_Attribute.BACK_BUTTON_SIZE)

def end_Program():
	pygame_display_quit()
	pygame_quit()
	quit()

def draw_Window1(Screen):
	Screen.blit(image1, imagerect1)
	Screen.blit(button_start_surface, gui_Attribute.BUTTON_START_POS)
	Screen.blit(button_exit_surface, gui_Attribute.BUTTON_EXIT_POS)
	Screen.blit(text_button_start, gui_Attribute.TEXT_BUTTON_START_POS)
	Screen.blit(text_button_exit, gui_Attribute.TEXT_BUTTON_EXIT_POS)
	pygame.display.update()

	global exit_game
	while exit_game == False:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				end_Program()				
			if event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1:
					mouse_x, mouse_y = pygame.mouse.get_pos()

					start_rect = pygame.Rect(gui_Attribute.BUTTON_START_POS, gui_Attribute.BUTTON_START_SIZE)
					exit_rect = pygame.Rect(gui_Attribute.BUTTON_EXIT_POS, gui_Attribute.BUTTON_EXIT_SIZE)

					if start_rect.collidepoint(mouse_x, mouse_y):
						input_box = Function.makeBoxFileInput()
						draw_Window2(Screen, input_box)

					if exit_rect.collidepoint(mouse_x, mouse_y):
						end_Program()

def draw_Input_Box(Screen, input_box):
	for box in input_box:
		box_input = pygame.Surface(box.box_size, pygame.SRCALPHA)
		box_input.fill(gui_Attribute.GRAY_BUTTON) 
		text_box = font3.render(box.name, True, gui_Attribute.BLACK)
		Screen.blit(box_input, box.box_pos)
		Screen.blit(text_box, box.text_pos)

def draw_Window2(Screen, input_box):
	Screen.blit(image1, imagerect1)
	Screen.blit(box_input_surface, gui_Attribute.BOX_INPUT_POS)
	Screen.blit(text_box_input, gui_Attribute.TEXT_BOX_INPUT_POS)
	draw_Input_Box(Screen, input_box)
	pygame.display.update()

	global exit_game
	while exit_game == False:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				end_Program()

			if event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1:
					mouse_x, mouse_y = pygame.mouse.get_pos()

					for box in input_box:
						box_rec = pygame.Rect(box.box_size, box.box_pos)
						if box_rec.collidepoint(mouse_x, mouse_y):
							draw_Window3(Screen, box.name)
							break


def draw_Window3(Screen, file_name):
	stone_weight, matrix = Function.readFile(file_name)
	Function.solveAllAlgorithm(stone_weight, matrix)

	Screen = pygame.display.set_mode((gui_Attribute.WIDTH2_SCREEN, gui_Attribute.HEIGHT2_SCREEN))	
	Screen.blit(image2, imagerect2)
	Screen.blit(box_controller, gui_Attribute.BOX_CONTROLLER_POS)
	Screen.blit(back_button, gui_Attribute.BACK_BUTTON_POS)
	pygame.display.update()

	global exit_game
	while exit_game == False:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				end_Program()

def draw_UI():
	pygame.init()

	Screen = pygame.display.set_mode((gui_Attribute.WIDTH1_SCREEN, gui_Attribute.HEIGHT1_SCREEN))
	pygame.display.set_caption('Ares’s adventure')

	draw_Window1(Screen)