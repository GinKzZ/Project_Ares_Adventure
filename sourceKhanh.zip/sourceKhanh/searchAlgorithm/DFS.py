def DFS_solve():
	print("Something")