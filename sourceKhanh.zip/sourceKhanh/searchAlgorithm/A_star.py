def A_star_solve():
	print("Something")