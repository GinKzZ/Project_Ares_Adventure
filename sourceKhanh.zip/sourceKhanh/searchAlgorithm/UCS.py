def UCS_solve():
	print("Something")