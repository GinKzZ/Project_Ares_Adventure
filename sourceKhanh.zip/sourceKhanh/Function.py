import os
from searchAlgorithm import *

class Box:
	def __init__(self, name, box_size, box_pos, text_pos):
		self.name = name
		self.box_size = box_size
		self.box_pos = box_pos
		self.text_pos = text_pos

def makeBoxFileInput():
	input_box = []
	folder_path = "Inputs"
	file_list = os.listdir(folder_path)

	width = 80
	height = 30
	numOfBox = 0
	numOfBoxOnLine = 3
	dis_from_leftSide = 35
	dis_from_top = 90
	dis_between_box_hor = 20
	dis_between_box_ver = 30

	for file in file_list:
		posX_temp = dis_from_leftSide + numOfBox*(width + dis_between_box_hor)
		posY_temp = dis_from_top
		input_box.append(Box(file, (width, height), (posX_temp, posY_temp), (posX_temp+1, posY_temp+7)))
		numOfBox += 1
		if numOfBox == numOfBoxOnLine:
			numOfBox = 0
			dis_from_top += height + dis_between_box_ver
	
	return input_box

def readFile(file_name):
	with open(os.getcwd() + "/Inputs/" + file_name, "r") as file:
		stone_weight = list(map(int, file.readline().split()))
		matrix = [list(line.rstrip("\n")) for line in file]
	return stone_weight, matrix

def solveAllAlgorithm(stone_weight, matrix):
	A_star_solve()
	BFS_solve()
	DFS_solve()
	GBFS_solve()
	UCS_solve()
	#lam sao tao ra file output chua ca 5 cai giup t