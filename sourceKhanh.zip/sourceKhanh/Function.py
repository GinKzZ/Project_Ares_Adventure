import os
from searchAlgorithm import *
from guiSource.gui_Attribute import WIDTH2_SCREEN, HEIGHT2_SCREEN, HEIGHT_BOX_CONTROLLER

WIDTH = 30

class Box:
	def __init__(self, name, box_size, box_pos, text_pos):
		self.name = name
		self.box_size = box_size
		self.box_pos = box_pos
		self.text_pos = text_pos

class Stone:
	def __init__(self, weight, S_size, S_pos):
		self.weight = str(weight)
		self.S_size = S_size
		self.S_pos = S_pos

class Ares:
	def __init__(self, A_size, A_pos):
		self.A_size = A_size
		self.A_pos = A_pos

#use dic to represent al -> Algorithm
class Algorithm:
	def __init__(self, name, step, listOfStep):
		self.name = name
		self.step = step
		self.listOfStep = listOfStep

def makeBoxFileInput():
	input_box = []
	folder_path = "Inputs"
	file_list = os.listdir(folder_path)

	width = 80
	height = 30
	numOfBox = 0
	numOfBoxOnLine = 3
	dis_from_leftSide = 35
	dis_from_top = 90
	dis_between_box_hor = 20
	dis_between_box_ver = 30

	for file in file_list:
		posX_temp = dis_from_leftSide + numOfBox*(width + dis_between_box_hor)
		posY_temp = dis_from_top
		input_box.append(Box(file, (width, height), (posX_temp, posY_temp), (posX_temp+1, posY_temp+7)))
		numOfBox += 1
		if numOfBox == numOfBoxOnLine:
			numOfBox = 0
			dis_from_top += height + dis_between_box_ver
	
	return input_box

def readFile(file_name):
	with open(os.getcwd() + "/Inputs/" + file_name, "r") as file:
		stone_weight = list(map(int, file.readline().split()))
		matrix = [list(line.rstrip("\n")) for line in file]
	return stone_weight, matrix

def makeStoneAndPerson(stone_weight, matrix):
	ares = ()
	countStone = 0
	countTop = 0
	dis_from_top = (HEIGHT2_SCREEN - HEIGHT_BOX_CONTROLLER - len(matrix)*WIDTH) / 2 + HEIGHT_BOX_CONTROLLER
	dis_from_leftSide = (WIDTH2_SCREEN - len(matrix[0])*WIDTH) / 2
	Stones = []
	for row in matrix:
		countLeft = 0
		for element in row:
			match element:
				case '$':
					Stones.append(Stone(stone_weight[countStone], (WIDTH, WIDTH), (dis_from_leftSide + WIDTH*countLeft, dis_from_top + WIDTH*countTop)))
					countStone += 1
				case '@':
					ares = Ares((WIDTH, WIDTH), (dis_from_leftSide + WIDTH*countLeft, dis_from_top + WIDTH*countTop))
				case '*':
					Stones.append(Stone(stone_weight[countStone], (WIDTH, WIDTH), (dis_from_leftSide + WIDTH*countLeft, dis_from_top + WIDTH*countTop)))
					countStone += 1
				case '+':
					ares = Ares((WIDTH, WIDTH), (dis_from_leftSide + WIDTH*countLeft, dis_from_top + WIDTH*countTop))
			countLeft += 1
		countTop += 1
	return Stones, ares, (dis_from_top, dis_from_leftSide)

def solveAllAlgorithm(stone_weight, matrix):
	A_star_solve()
	BFS_solve()
	DFS_solve()
	GBFS_solve()
	UCS_solve()
	#lam sao tao ra file output chua ca 5 cai giup t