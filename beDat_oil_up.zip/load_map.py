import os
from bfs import bfs_solve
from dfs import dfs_solve
from A_star import astar_solve
from UCS import ucs_solve

def list_input_files(directory="input"):
    """ List all available map files in the input directory. """
    return [f for f in os.listdir(directory) if f.endswith(".txt")]


def load_map(file_path):
    """
    Load Sokoban map from a text file.

    Returns:
    - maze: 2D list representing the map.
    - player_pos: Tuple (x, y) representing the player's position.
    - stone_positions: List of tuples representing stone positions.
    - switch_positions: List of tuples representing target positions.
    - stone_weights: Dictionary mapping stone positions to their respective weights.
    """
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Read stone weights from the first line
    stone_weights_list = list(map(int, lines[0].split()))

    # Read the maze map
    maze = []
    player_pos = None
    stone_positions = []
    switch_positions = []
    stone_weights = {}
    stone_count = 0  # Track stones to assign weights correctly

    for i, line in enumerate(lines[1:]):
        row = list(line.rstrip())
        maze.append(row)
        for j, cell in enumerate(row):
            if cell == '@':
                player_pos = (i, j)
            elif cell == '$':
                stone_positions.append((i, j))
                stone_weights[(i, j)] = stone_weights_list[stone_count]
                stone_count += 1
            elif cell == '.':
                switch_positions.append((i, j))

    return {
        "maze": maze,
        "player_pos": player_pos,
        "stone_positions": stone_positions,
        "switch_positions": switch_positions,
        "stone_weights": stone_weights
    }


def load_all_maps(directory="input"):
    """ Load all Sokoban maps from the input directory into a list. """
    files = list_input_files(directory)
    maps = {}
    for file in files:
        file_path = os.path.join(directory, file)
        maps[file] = load_map(file_path)
    return maps


def print_map(map_data):
    """ Print a specific Sokoban map from the loaded maps. """
    print("Maze:")
    for row in map_data["maze"]:
        print("".join(row))
    print(f"Player Position: {map_data['player_pos']}")
    print(f"Stone Positions: {map_data['stone_positions']}")
    print(f"Switch Positions: {map_data['switch_positions']}")
    print(f"Stone Weights: {map_data['stone_weights']}")


def main():
    input_directory = "input"
    maps = load_all_maps(input_directory)
    if not maps:
        print("No input files found in the 'input' directory.")
        return

    print("Available map files:")
    files = list(maps.keys())
    for i, file in enumerate(files):
        print(f"{i + 1}: {file}")

    choice = input("Select a file by number: ")
    if not choice.isdigit() or not (1 <= int(choice) <= len(files)):
        print("Invalid selection.")
        return
    selected_file = files[int(choice) - 1]
    print_map(maps[selected_file])

    # Menu chọn thuật toán
    algorithms = {
        "1": ("BFS", bfs_solve),
        "2": ("DFS", dfs_solve),
        "3": ("A*", astar_solve),
        "4": ("UCS", ucs_solve),
    }
    print("\nSelect an algorithm to solve:")
    for key, (name, _) in algorithms.items():
        print(f"{key}: {name}")

    algo_choice = input("Enter the number of the algorithm: ")
    if algo_choice not in algorithms:
        print("Invalid selection.")
        return

    algo_name, algo_func = algorithms[algo_choice]
    walls = {(i, j) for i, row in enumerate(maps[selected_file]["maze"]) for j, cell in enumerate(row) if cell == "#"}
    result = algo_func(walls, maps[selected_file]["player_pos"],
                       set(maps[selected_file]["stone_positions"]), set(maps[selected_file]["switch_positions"]),
                       maps[selected_file]["stone_weights"])

    if result:
        print(
            f"{algo_name} :\nSteps: {result['steps']}, Weight: {result['weight']}, Node: {result['nodes']}, Time (ms): {result['time']:.2f}, Memory (MB): {result['memory']:.2f}")
        print(result['path'])
    else:
        print("No solution found.")


if __name__ == "__main__":
    main()
