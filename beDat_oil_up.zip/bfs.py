import collections
import time
import psutil
import sys


def bfs_solve(maze, player_pos, stones, targets, stone_weights):
    """
    Solve Sokoban using BFS (Breadth-First Search), ignoring weights.
    """
    start_time = time.time()
    process = psutil.Process()
    start_memory = process.memory_info().rss / (1024 * 1024)  # Memory in MB

    queue = collections.deque()
    initial_state = (player_pos, frozenset(stones))
    queue.append((initial_state, [], 0, 0))  # (state, path, steps, nodes)
    visited = set()
    visited.add(initial_state)
    nodes = 0

    directions = [(-1, 0, 'u'), (1, 0, 'd'), (0, -1, 'l'), (0, 1, 'r')]

    while queue:
        (player, stones), path, steps, cost = queue.popleft()
        nodes += 1

        # Check if all stones are on target positions
        if all(stone in targets for stone in stones):
            end_time = time.time()
            memory_used = process.memory_info().rss / (1024 * 1024) - start_memory
            return {
                "steps": steps,
                "weight": cost,
                "nodes": nodes,
                "time": (end_time - start_time) * 1000,  # Convert to ms
                "memory": memory_used,
                "path": "".join(path)
            }

        for dx, dy, move in directions:
            new_player = (player[0] + dx, player[1] + dy)
            if new_player in stones:
                pushed = (new_player[0] + dx, new_player[1] + dy)
                if pushed not in maze and pushed not in stones:
                    new_stones = set(stones)
                    new_stones.remove(new_player)
                    new_stones.add(pushed)
                    new_state = (new_player, frozenset(new_stones))
                    if new_state not in visited:
                        visited.add(new_state)
                        queue.append(
                            (new_state, path + [move.upper()], steps + 1, cost + 1 + stone_weights.get(new_player, 0)))
            else:
                if new_player not in maze:
                    new_state = (new_player, stones)
                    if new_state not in visited:
                        visited.add(new_state)
                        queue.append((new_state, path + [move], steps + 1, cost + 1))

    return None  # No solution found


# Example usage:
if __name__ == "__main__":
    maze = {(1, 1), (2, 1), (3, 1)}  # Example walls
    player_pos = (4, 4)
    stones = {(2, 2), (3, 3)}
    targets = {(5, 5), (6, 6)}
    stone_weights = {(2, 2): 1, (3, 3): 2}

    result = bfs_solve(maze, player_pos, stones, targets, stone_weights)
    if result:
        print(
            f"BFS :\nSteps: {result['steps']}, Weight: {result['weight']}, Node: {result['nodes']}, Time (ms): {result['time']:.2f}, Memory (MB): {result['memory']:.2f}")
        print(result['path'])
    else:
        print("No solution found.")
