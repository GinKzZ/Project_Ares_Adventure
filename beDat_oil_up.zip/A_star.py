import heapq
import time
import psutil
import sys


def heuristic(stones, targets):
    """ Heuristic function: Sum of Manhattan distances from stones to their nearest targets. """
    return sum(min(abs(sx - tx) + abs(sy - ty) for tx, ty in targets) for sx, sy in stones)


def astar_solve(maze, player_pos, stones, targets, stone_weights):
    """
    Solve Sokoban using A* search algorithm with improved heuristic and debugging.
    """
    start_time = time.time()
    process = psutil.Process()
    start_memory = process.memory_info().rss / (1024 * 1024)  # Memory in MB

    priority_queue = []
    tie_breaker = 0  # Ensure stable sorting in heapq
    initial_state = (player_pos, frozenset(stones))
    heapq.heappush(priority_queue,
                   (heuristic(stones, targets), tie_breaker, 0, initial_state, []))  # (f, tie, g, state, path)
    visited = {}
    visited[initial_state] = float('inf')  # Track best cost for each state
    nodes = 0
    parents = {}  # Track path

    directions = [(-1, 0, 'u'), (1, 0, 'd'), (0, -1, 'l'), (0, 1, 'r')]

    while priority_queue:
        _, _, cost, (player, stones), path = heapq.heappop(priority_queue)
        nodes += 1

        # Debugging output
        if nodes % 1000 == 0:
            print(f"Nodes expanded: {nodes}, Current cost: {cost}, Heuristic: {heuristic(stones, targets)}")

        # Goal check
        if all(stone in targets for stone in stones):
            print("Solution found!")
            end_time = time.time()
            memory_used = process.memory_info().rss / (1024 * 1024) - start_memory
            return {
                "steps": len(path),
                "weight": cost,
                "nodes": nodes,
                "time": (end_time - start_time) * 1000,  # Convert to ms
                "memory": memory_used,
                "path": "".join(path)
            }

        for dx, dy, move in directions:
            new_player = (player[0] + dx, player[1] + dy)
            if new_player in stones:
                pushed = (new_player[0] + dx, new_player[1] + dy)
                if pushed not in maze and pushed not in stones:
                    new_stones = set(stones)
                    new_stones.remove(new_player)
                    new_stones.add(pushed)
                    new_state = (new_player, frozenset(new_stones))
                    new_cost = cost + 1 + stone_weights.get(new_player, 0)

                    if new_cost < visited.get(new_state, float('inf')):
                        visited[new_state] = new_cost
                        heapq.heappush(priority_queue, (
                        new_cost + heuristic(new_stones, targets), tie_breaker, new_cost, new_state,
                        path + [move.upper()]))
                        parents[new_state] = (player, stones, move.upper())
                        tie_breaker += 1
            else:
                if new_player not in maze:
                    new_state = (new_player, stones)
                    new_cost = cost + 1

                    if new_cost < visited.get(new_state, float('inf')):
                        visited[new_state] = new_cost
                        heapq.heappush(priority_queue, (
                        new_cost + heuristic(stones, targets), tie_breaker, new_cost, new_state, path + [move]))
                        parents[new_state] = (player, stones, move)
                        tie_breaker += 1

    print("No solution found.")
    return None  # No solution found


# Example usage:
if __name__ == "__main__":
    maze = {(1, 1), (2, 1), (3, 1)}  # Example walls
    player_pos = (4, 4)
    stones = {(2, 2), (3, 3)}
    targets = {(5, 5), (6, 6)}
    stone_weights = {(2, 2): 1, (3, 3): 2}

    result = astar_solve(maze, player_pos, stones, targets, stone_weights)
    if result:
        print(
            f"A* :\nSteps: {result['steps']}, Weight: {result['weight']}, Node: {result['nodes']}, Time (ms): {result['time']:.2f}, Memory (MB): {result['memory']:.2f}")
        print(result['path'])
    else:
        print("No solution found.")
