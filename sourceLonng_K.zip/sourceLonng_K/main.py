from guiSource import gui_Source

def main():
	gui_Source.draw_UI()

if __name__ == "__main__":
	main()
