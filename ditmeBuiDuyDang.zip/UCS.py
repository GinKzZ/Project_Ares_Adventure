import heapq
def bfs_solve(maze, weights):
    """
    Tính lời giải cho mê cung bằng Uniform Cost Search.

    Input:
      - maze: ma trận static (list of list) chứa tường, switch, ô trống.
      - weights: danh sách trọng số của các viên đá theo thứ tự duyệt map.

    Output:
      - solution_path: danh sách các bước di chuyển, mỗi bước là một chuỗi:
          * "U", "D", "L", "R" cho di chuyển không đẩy,
          * "PU", "PD", "PL", "PR" cho các bước đẩy (đẩy viên đá đi theo hướng tương ứng).
      - cost: tổng chi phí (mỗi bước di chuyển + bước đẩy có chi phí = 1 + trọng số viên đá).
    """
    n = len(maze)
    m = len(maze[0])
    walls = set()
    switches = set()
    # Lấy thông tin các ô tường và switch (ô công tắc)
    for i in range(n):
        for j in range(m):
            if maze[i][j] == '#':
                walls.add((i, j))
            elif maze[i][j] == '.':
                switches.add((i, j))
    # Xác định vị trí ban đầu của Ares và các viên đá từ maze, theo thứ tự duyệt map.
    ares_start = None
    stone_list = []  # mỗi phần tử ((i,j), weight)
    weight_index = 0
    for i in range(n):
        for j in range(m):
            cell = maze[i][j]
            if cell in ('@', '+'):
                ares_start = (i, j)
            elif cell in ('$', '*'):
                if weight_index < len(weights):
                    stone_list.append(((i, j), weights[weight_index]))
                    weight_index += 1
    if ares_start is None:
        raise ValueError("Không tìm thấy vị trí Ares trong map.")
    initial_state = (ares_start, frozenset(stone_list))

    # Sử dụng heapq cho tìm kiếm chi phí đồng đều.
    frontier = []
    counter = 0
    heapq.heappush(frontier, (0, counter, initial_state, []))  # (cost, counter, state, path)
    visited = {initial_state: 0}

    # Định nghĩa 4 hướng di chuyển:
    # Mỗi hướng gồm (dx, dy, ký hiệu di chuyển, ký hiệu đẩy)
    directions = [
        (-1, 0, 'U', 'PU'),
        (1, 0, 'D', 'PD'),
        (0, -1, 'L', 'PL'),
        (0, 1, 'R', 'PR')
    ]

    while frontier:
        cost, _, state, path = heapq.heappop(frontier)
        ares_pos, stones = state

        # Nếu tất cả các viên đá đều nằm trên switch, đã hoàn thành.
        if all(s in switches for s, _ in stones):
            return path, cost

        for dx, dy, move_char, push_char in directions:
            new_ares = (ares_pos[0] + dx, ares_pos[1] + dy)
            if not (0 <= new_ares[0] < n and 0 <= new_ares[1] < m):
                continue
            if new_ares in walls:
                continue
            # Tập hợp vị trí các viên đá hiện tại.
            stone_positions = {s for s, _ in stones}
            if new_ares in stone_positions:
                # Nếu ô kề có viên đá, chỉ cho phép đẩy nếu ô sau đó hợp lệ.
                pushed_pos = (new_ares[0] + dx, new_ares[1] + dy)
                if not (0 <= pushed_pos[0] < n and 0 <= pushed_pos[1] < m):
                    continue
                if pushed_pos in walls or pushed_pos in stone_positions:
                    continue
                # Tìm viên đá tại new_ares và cập nhật vị trí của nó.
                stone_weight = None
                new_stones = set(stones)
                for s, w in stones:
                    if s == new_ares:
                        stone_weight = w
                        new_stones.remove((s, w))
                        new_stones.add((pushed_pos, w))
                        break
                if stone_weight is None:
                    continue
                new_state = (new_ares, frozenset(new_stones))
                new_cost = cost + 1 + stone_weight
                new_path = path + [push_char]
                if new_state not in visited or new_cost < visited[new_state]:
                    visited[new_state] = new_cost
                    counter += 1
                    heapq.heappush(frontier, (new_cost, counter, new_state, new_path))
            else:
                # Di chuyển không đẩy.
                new_state = (new_ares, stones)
                new_cost = cost + 1
                new_path = path + [move_char]
                if new_state not in visited or new_cost < visited[new_state]:
                    visited[new_state] = new_cost
                    counter += 1
                    heapq.heappush(frontier, (new_cost, counter, new_state, new_path))
    return [], 0
