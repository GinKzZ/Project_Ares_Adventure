import pygame
import os
import threading
import time
from BFS import bfs_solve

pygame.init()
screen_width, screen_height = 1000, 700
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Ares's Adventure")
icon = pygame.image.load('assets/pickaxe.png')
pygame.display.set_icon(icon)
clock = pygame.time.Clock()

tile_size = 48
# Tải hình ảnh đối tượng
AresImg = pygame.transform.scale(pygame.image.load('assets/miner.png'), (tile_size, tile_size))
StoneImg = pygame.transform.scale(pygame.image.load('assets/rock.png'), (tile_size, tile_size))
WallImg = pygame.transform.scale(pygame.image.load('assets/wall.png'), (tile_size, tile_size))
DesImg = pygame.transform.scale(pygame.image.load('assets/bullet-point.png'), (tile_size, tile_size))
CompleteStoneImg = pygame.transform.scale(pygame.image.load('assets/diamond.png'), (tile_size, tile_size))
AresOnSwitchImg = pygame.transform.scale(pygame.image.load('assets/tent.png'), (tile_size, tile_size))

background_color = (77, 77, 77)
white = (255, 255, 255)
black = (0, 0, 0)

# Các biến toàn cục
# Ở phiên bản BFS “pure” (không dùng trọng số) state chứa: (ares_pos, frozenset(stone_positions))
weights = []         # Chỉ đọc từ file input (không dùng cho state)
static_maze = []     # Ma trận mê cung tĩnh
current_state = None # (ares_pos, stones) – stones là frozenset các vị trí (i, j)

# Biến cho giải pháp
solution_path = None  # Danh sách các bước di chuyển (ví dụ: ["U", "L", "PU", ...])
total_cost = 0
anim_index = 0        # Chỉ số bước hiện tại trong solution_path
next_move_time = 0    # Thời gian thực hiện bước kế tiếp

input_files = [f for f in os.listdir('input') if f.endswith('.txt')]
selected_file_index = -1

input_loaded = False  # Đã chọn file và nạp maze chưa

# Dropdown chọn file
dropdown_expanded = False
scroll_offset = 0
visible_options = 5
selected_file_name = "Click to select"
dropdown_rect = pygame.Rect(400, 300, 200, 50)
# Nút Start giải
button_rect = pygame.Rect(10, 10, 120, 50)

def load_maze_from_file(file_path):
    global weights, static_maze
    with open(file_path, 'r') as file:
        lines = file.read().splitlines()
        # Dòng đầu chứa trọng số của viên đá (đã đọc nhưng không dùng cho state)
        weights = list(map(int, lines[0].split()))
        maze_lines = lines[1:]
        max_width = max(len(line) for line in maze_lines)
        static_maze = [list(line.ljust(max_width)) for line in maze_lines]

def init_state_from_maze():
    """
    Khởi tạo state ban đầu từ static_maze: tìm vị trí Ares và các viên đá.
    Phiên bản này chỉ lưu vị trí (i, j) của các viên đá (không kèm trọng số).
    """
    global current_state
    ares_start = None
    stone_list = []
    for i in range(len(static_maze)):
        for j in range(len(static_maze[0])):
            cell = static_maze[i][j]
            if cell in ('@', '+'):
                ares_start = (i, j)
            elif cell in ('$', '*'):
                stone_list.append((i, j))
    if ares_start is None:
        ares_start = (0, 0)
    current_state = (ares_start, frozenset(stone_list))

def draw_static_maze():
    if not static_maze:
        return
    rows = len(static_maze)
    cols = len(static_maze[0])
    maze_width = cols * tile_size
    maze_height = rows * tile_size
    start_x = (screen_width - maze_width) // 2
    start_y = (screen_height - maze_height) // 2
    for i in range(rows):
        for j in range(cols):
            pos = (start_x + j * tile_size, start_y + i * tile_size)
            cell = static_maze[i][j]
            if cell == '#':
                screen.blit(WallImg, pos)
            elif cell == '.':
                screen.blit(DesImg, pos)
            else:
                pygame.draw.rect(screen, background_color, (pos[0], pos[1], tile_size, tile_size))

def draw_state(ares_pos, stones):
    """
    Vẽ Ares và các viên đá theo current_state.
    stones là frozenset các vị trí (i, j).
    """
    rows = len(static_maze)
    cols = len(static_maze[0])
    maze_width = cols * tile_size
    maze_height = rows * tile_size
    start_x = (screen_width - maze_width) // 2
    start_y = (screen_height - maze_height) // 2
    # Vẽ Ares
    ares_x = ares_pos[1] * tile_size + start_x
    ares_y = ares_pos[0] * tile_size + start_y
    if static_maze[ares_pos[0]][ares_pos[1]] == '.':
        screen.blit(AresOnSwitchImg, (ares_x, ares_y))
    else:
        screen.blit(AresImg, (ares_x, ares_y))
    # Vẽ các viên đá
    for (i, j) in stones:
        pos = (j * tile_size + start_x, i * tile_size + start_y)
        if static_maze[i][j] == '.':
            screen.blit(CompleteStoneImg, pos)
        else:
            screen.blit(StoneImg, pos)

def draw_dropdown(rect, options, selected_index, expanded, scroll_offset, selected_file_name):
    pygame.draw.rect(screen, white, rect)
    font = pygame.font.Font(None, 36)
    display_text = selected_file_name if selected_file_name != "" else "Click to select"
    text_surface = font.render(display_text, True, black)
    screen.blit(text_surface, (rect[0] + 10, rect[1] + 10))
    if expanded:
        for i in range(min(visible_options, len(options) - scroll_offset)):
            option_rect = pygame.Rect(rect[0], rect[1] + (i + 1) * 50, rect[2], 50)
            pygame.draw.rect(screen, white, option_rect)
            text_surface = font.render(options[scroll_offset + i], True, black)
            screen.blit(text_surface, (option_rect[0] + 10, option_rect[1] + 10))

def update_state(ares_pos, stones):
    global current_state
    current_state = (ares_pos, stones)

# Hàm pause_callback: nếu không cần chức năng tạm dừng, chỉ đơn giản là pass.
def pause_callback():
    pass

def apply_move(state, move):
    """
    state: (ares_pos, stones) hiện tại.
    move: chuỗi ký hiệu, ví dụ "R" hay "PR".
    Output: state mới sau khi di chuyển.
    """
    ares_pos, stones = state
    dir_map = {
        'U': (-1, 0),
        'D': (1, 0),
        'L': (0, -1),
        'R': (0, 1)
    }
    if move in ['U', 'D', 'L', 'R']:
        dx, dy = dir_map[move]
        new_ares = (ares_pos[0] + dx, ares_pos[1] + dy)
        return (new_ares, stones)
    elif move.startswith('P'):
        direction = move[1]
        dx, dy = dir_map[direction]
        new_ares = (ares_pos[0] + dx, ares_pos[1] + dy)
        new_stones = set(stones)
        if new_ares in new_stones:
            new_stones.remove(new_ares)
            pushed = (new_ares[0] + dx, new_ares[1] + dy)
            new_stones.add(pushed)
        return (new_ares, frozenset(new_stones))
    else:
        return state

def compute_solution():
    global solution_path, total_cost
    solution_path, total_cost = bfs_solve(static_maze, update_state, pause_callback)
    print("BFS hoàn thành: cost =", total_cost, "path =", solution_path)

def animate_solution():
    global anim_index, next_move_time, current_state, solution_path
    if solution_path is None or anim_index >= len(solution_path):
        return
    if time.time() >= next_move_time:
        move = solution_path[anim_index]
        current_state = apply_move(current_state, move)
        anim_index += 1
        next_move_time = time.time() + 1

def start_solution():
    global solution_path, total_cost, anim_index, next_move_time
    def run_bfs():
        compute_solution()
    threading.Thread(target=run_bfs).start()
    anim_index = 0
    next_move_time = time.time() + 1

running = True
while running:
    screen.fill(background_color)
    if input_loaded:
        draw_static_maze()
        if current_state is not None:
            ares_pos, stones = current_state
            draw_state(ares_pos, stones)
        pygame.draw.rect(screen, white, button_rect)
        font = pygame.font.Font(None, 24)
        btn_text = "Start" if solution_path is None else "Animating"
        btn_surface = font.render(btn_text, True, black)
        screen.blit(btn_surface, (button_rect.x + 10, button_rect.y + 10))
        if solution_path is not None and anim_index < len(solution_path):
            animate_solution()
        elif solution_path is not None and anim_index >= len(solution_path):
            cost_text = f"Total Cost: {total_cost}"
            cost_surface = font.render(cost_text, True, white)
            screen.blit(cost_surface, (button_rect.x, button_rect.y + 60))
    else:
        draw_dropdown(dropdown_rect, input_files, selected_file_index, dropdown_expanded, scroll_offset, selected_file_name)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if not input_loaded:
                if dropdown_rect.collidepoint(event.pos):
                    dropdown_expanded = not dropdown_expanded
                elif dropdown_expanded:
                    for i in range(min(visible_options, len(input_files) - scroll_offset)):
                        option_rect = pygame.Rect(dropdown_rect.x, dropdown_rect.y + (i + 1) * 50, dropdown_rect.width, 50)
                        if option_rect.collidepoint(event.pos):
                            selected_file_index = scroll_offset + i
                            selected_file_name = input_files[selected_file_index]
                            file_path = os.path.join('input', selected_file_name)
                            load_maze_from_file(file_path)
                            init_state_from_maze()
                            input_loaded = True
                            dropdown_expanded = False
            else:
                if button_rect.collidepoint(event.pos) and solution_path is None:
                    start_solution()
        elif event.type == pygame.MOUSEWHEEL:
            if dropdown_expanded:
                scroll_offset -= event.y
                scroll_offset = max(0, min(scroll_offset, len(input_files) - visible_options))
    pygame.display.update()
    clock.tick(60)
pygame.quit()
