# bfs.py
import collections
import time
def bfs_solve(maze, update_callback, pause_callback):
    """
    Tìm lời giải cho mê cung bằng thuật toán BFS (không quan tâm trọng số).

    Input:
      - maze: Ma trận (list of list) chứa các ký tự của mê cung.
      - update_callback(ares_pos, stones): Hàm callback cập nhật state cho giao diện.
      - pause_callback(): Hàm kiểm tra trạng thái tạm dừng; nếu đang pause thì chờ.

    Output:
      - solution_path: Danh sách các bước di chuyển (mỗi bước là "U", "D", "L", "R" cho di chuyển,
        hoặc "PU", "PD", "PL", "PR" cho bước đẩy viên đá).
      - cost: Tổng số bước (tức là số nước đi).
    """
    n = len(maze)
    m = len(maze[0])

    walls = set()
    switches = set()
    # Xác định các ô tường và ô công tắc.
    for i in range(n):
        for j in range(m):
            if maze[i][j] == '#':
                walls.add((i, j))
            elif maze[i][j] == '.':
                switches.add((i, j))

    # Xác định vị trí ban đầu của Ares và các viên đá (chỉ lưu vị trí).
    ares_start = None
    stone_positions = []
    for i in range(n):
        for j in range(m):
            cell = maze[i][j]
            if cell in ('@', '+'):
                ares_start = (i, j)
            elif cell in ('$', '*'):
                stone_positions.append((i, j))
    if ares_start is None:
        raise ValueError("Không tìm thấy vị trí bắt đầu của Ares.")
    initial_state = (ares_start, frozenset(stone_positions))

    queue = collections.deque()
    queue.append((initial_state, []))  # Mỗi phần tử: (state, path)
    visited = set()
    visited.add(initial_state)

    # Định nghĩa 4 hướng di chuyển:
    # Mỗi hướng gồm (dx, dy, ký hiệu di chuyển, ký hiệu đẩy)
    directions = [
        (-1, 0, 'U', 'PU'),
        (1, 0, 'D', 'PD'),
        (0, -1, 'L', 'PL'),
        (0, 1, 'R', 'PR')
    ]

    while queue:
        pause_callback()  # Nếu đang tạm dừng, hàm sẽ chờ.
        state, path = queue.popleft()
        ares_pos, stones = state

        # Cập nhật giao diện state hiện tại.
        update_callback(ares_pos, stones)

        # Kiểm tra nếu tất cả các viên đá đã được đẩy vào ô công tắc.
        if all(s in switches for s in stones):
            print("Đã tìm được lời giải với số bước:", len(path))
            return path, len(path)

        # Duyệt 4 hướng.
        for dx, dy, move_char, push_char in directions:
            new_ares = (ares_pos[0] + dx, ares_pos[1] + dy)
            # Kiểm tra giới hạn và tường.
            if not (0 <= new_ares[0] < n and 0 <= new_ares[1] < m):
                continue
            if new_ares in walls:
                continue

            # Nếu ô mới không có viên đá, chỉ di chuyển.
            if new_ares not in stones:
                new_state = (new_ares, stones)
                if new_state not in visited:
                    visited.add(new_state)
                    new_path = path + [move_char]
                    queue.append((new_state, new_path))
            else:
                # Nếu ô mới có viên đá, thử đẩy viên đá sang ô kế.
                pushed_pos = (new_ares[0] + dx, new_ares[1] + dy)
                if not (0 <= pushed_pos[0] < n and 0 <= pushed_pos[1] < m):
                    continue
                if pushed_pos in walls or pushed_pos in stones:
                    continue
                new_stones = set(stones)
                new_stones.remove(new_ares)
                new_stones.add(pushed_pos)
                new_state = (new_ares, frozenset(new_stones))
                if new_state not in visited:
                    visited.add(new_state)
                    new_path = path + [push_char]
                    queue.append((new_state, new_path))

    print("Không tìm được lời giải.")
    return [], 0
