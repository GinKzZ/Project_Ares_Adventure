1/ How to build and run the program:
Step 1: Install all required libraries. (in file requirements.txt)
Step 2: build file main.py
2/ How to use GUI:
- Window 1: choose start or exit.
- Window 2: choose your input file.
- Window 3: we have some functions like:
	+ If you press the back button, we can choose input file again.
	+ A box to choose search algorithm. If we haven't choose yet, the default is BFS.
	+ Start button to start moving on the matrix.
	+ Pause button and reset button.

Notice: +when using GUI, remember to reset before using another search algorithm.
	+please wait a moment if the execute file is not responding.



